<?php
class user extends CI_Model{
    public function get_where($email, $passwrod)
    {
        return
    }
}