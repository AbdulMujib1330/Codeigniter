<?php

// session_start();
// if(!isset($_SESSION["nama_resepsionis"])) { 
//    header("Location:proses_login_resepsionis.php");
// }
?>
  <!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../style_css/login.css">
  <title>Sign-In</title>
</head>
  <!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<body>
  <!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<form action="auth" method="post">
<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 py-2 text-center">

            <div class="mb-md-4 mt-md-4 pb-2">

              <h2 class="fw-bold mb-2 text-uppercase">Sign-In</h2>
              <p class="text-white-50 mb-5">Create Your Account</p>

              <div class="form-outline form-white mb-2">
                <input type="email" id="typeEmailX" class="form-control form-control-lg" name="email" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-2">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" name="password" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              <div class="form-outline form-white mb-2">
                <input type="nama" class="form-control form-control-lg" name="nama" />
                <label class="form-label">Nama</label>
              </div>


              <button class="btn btn-outline-light btn-lg px-5" type="submit">Create</button>

            </div>

            <div>
              <p class="mb-0">Already have an account? <a href="login" class="text-white-50 fw-bold">Log-In <a class="text-light">/</a><a onclick="return confirm('Ingin Keluar?')"  href="homepage" class=""> Home</a></a>
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
  <!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
</body>
</html>
<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Sign</title>
</head>
<body>
<form action="../proses/sign.php" method="post">
    <div class="container">
        <div class="row">
        <div class="col-md-6 offset-md-3">
        <marquee behavior="" direction=""><h1>---------------Login---------------</h></marquee>
            <div class="card my-5 w-85">
                <div class="card text-center">
                    <h6 class="pb-5 positioning">Login Your Account</h6>    
                </div>
                <form class="card-body cardbody-color p-lg-5">
                    <div class="mb-3 w-50">
                        <input type="text" class="form-control" name="nama" placeholder="nama">
                    </div>
                    <div class="mb-3 w-50">
                        <input type="password" class="form-control" name="password" placeholder="password">
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-light btn-outline-success px-5 mb-2 w-150">Sign</button>
                    <br>
                        <a href="login.php" class="text-center mb-2">Login</a>
                    </div>
                </form>
            </div>
        </div>
        </div>
    </div>
</form>
</body>
</html> -->