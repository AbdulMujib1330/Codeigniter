<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Home page</title>
</head>
<style>
    a{
        text-decoration: none;
    }
</style>    
<body>
    </html>

    <div class="bg-light">
        <div class="mx-auto d-flex justify-content-between container">
            <a class="h2 d-block" href="#">Home Page</a>
            
            <div class="d-flex align-items-center">
                <a href="homepage" class="text-dark-50 fw-bold btn btn-outline-dark">Logout<a class="text-light">/</a>
            </div>  
        </div>
</div>

<!-- <table class="table table-bordered border-dark">
                            <thead>
                                <tr>
                                    <td class="text-dark">Nis</td>
                                    <td class="text-dark">Nama</td>
                                    <td class="text-dark">Kelas</td>
                                    <td class="text-dark">Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                            <?php while($data = $query->fetch()): ?>
                                <tr>
                                    <td class="text-dark"><?= $data['Nis'] ?></td>
                                    <td class="text-dark"><?= $data['Nama'] ?></td>
                                    <td class="text-dark"><?= $data['Kelas'] ?></td>
                                    <td class="text-dark">
                                        <a                                                        href="edit.php?NIS=<?= $data['Nis'] ?>"class="texta btn btn-outline-dark">Update</a>
                                        <a onclick="return confirm('Want To Delete This Data?')"  href="../Proses/delete.php?NIS=<?= $data['Nis'] ?>"class="texta btn btn-outline-dark">Delete</a>
                                    </td>
                                </tr>
                                <?php endwhile?>
                                </tbody>
</table> -->
</body>