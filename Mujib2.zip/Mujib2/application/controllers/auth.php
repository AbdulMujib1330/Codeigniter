<?php
defined('BASEPATH') or exit('No direct script access allowed');

class auth extends CI_Controller
{
	// public function signin()
	// {
	// 	$this->load->view('sign');
	// }

	public function login()
	{
		$this->load->view('login');
	}

	public function home()
	{
		$this->load->view('homepage');
	}






	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	function index()
	{
		// $this->load->database();
		$data['akun'] = $this->db->get('akun')->result_array();
		$this->load->view('sign', $data);
	}
	function signin()
	{
		$this->load->view('sign');
	}
	function proses_tambah()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$nama = $this->input->post('nama');

		$query = $this->db->insert('akun', array(`nama` => $nama, `password` => $password));
		if ($query) {
			redirect('sign');
		}
	}
}
