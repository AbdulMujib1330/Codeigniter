<?php
    session_start();
    // var_dump($_SESSION);
    // if (!$Nama['Nama'])
    if(!isset($_SESSION["Email"])) { 
        $_SESSION['Nama'] == $_SESSION['Nama'];
    header("Location:login");
    }








// $Email = $_POST["Email"];
// $Password = $_POST["Password"];
// // $Nama = $_POST["Nama"];
// $query = $database->query("select *  from admin where email='$Email' AND password='$Password'");
// $data = $query->fetch();
// if($data!=(false))
// {
//    // $_SESSION['Email'] = $Email;
//    // $_SESSION['Password'] = $data['Password'];

//    // if($data['Password']=="Password"){
//    //   header("Location:../Tampilan/data.php");
//    // }
//    $_SESSION["Email"] = $_POST["Email"];
//    $_SESSION["Password"] = $_POST["Password"];
// //    $_SESSION["Nama"] = $Nama;
//    header("Location:tampilan");
// }
//    else{
//        header("Location:login");
       
//        echo "<script>alert('Email atau password Anda salah. Silahkan coba lagi!')</script>";
//    }